#Оголосимо модуль Printable
module Printable
  def print_info
    puts "Information about the object:"
    instance_variables.each do |var|
      puts "#{var}: #{instance_variable_get(var)}"
    end
  end
end

#Створимо клас, до якого додамо метод print_info
class MyClass
  #Включемо модуль Printable у клас
  include Printable

  def initialize(name, age)
    @name = name
    @age = age
  end
end

#Створемо об'єкт класу MyClass
my_object = MyClass.new("David", 30)

#Викликаємо метод print_info для виведення інформації про об'єкт
my_object.print_info
